import React from "react";

interface MarqueeItem {
  id: string;
  title: string;
  image: string;
}

const COLUMN_A: MarqueeItem[] = [
  {
    id: "m-1-1",
    title: "Брендированные футболки",
    image: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-1-2",
    title: "Печать на пакетах",
    image: "https://images.unsplash.com/photo-1589362189157-44c6b12aa084?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-1-3",
    title: "Сувенирная продукция",
    image: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-1-4",
    title: "Наружная реклама",
    image: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=600&auto=format&fit=crop"
  }
];

const COLUMN_B: MarqueeItem[] = [
  {
    id: "m-2-1",
    title: "Лазерная гравировка",
    image: "https://images.unsplash.com/photo-1618090584176-7132b9911657?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-2-2",
    title: "Ручки с логотипом",
    image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-2-3",
    title: "Наградные кубки",
    image: "https://images.unsplash.com/photo-1518063319789-7217e6706b04?q=80&w=600&auto=format&fit=crop"
  },
  {
    id: "m-2-4",
    title: "Воздушные шары с печатью",
    image: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?q=80&w=600&auto=format&fit=crop"
  }
];

// Duplicate items to ensure seamless scroll
const FIRST_COLUMN = [...COLUMN_A, ...COLUMN_A, ...COLUMN_A];
const SECOND_COLUMN = [...COLUMN_B, ...COLUMN_B, ...COLUMN_B];

export default function Marquee() {
  return (
    <div className="relative h-[650px] w-full overflow-hidden rounded-3xl bg-neutral-100/50 p-2 border border-black/5">
      {/* Absolute Gradient Fade Masks for top and bottom */}
      <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#fafafa] to-transparent z-10 pointer-events-none"></div>
      <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-[#fafafa] to-transparent z-10 pointer-events-none"></div>

      {/* Grid container with two columns */}
      <div className="grid grid-cols-2 gap-4 h-full">
        {/* Left column - scrolling UP */}
        <div className="h-full overflow-hidden relative">
          <div className="flex flex-col gap-4 animate-marquee-up py-2">
            {FIRST_COLUMN.map((item, index) => (
              <div
                key={`${item.id}-${index}`}
                className="group relative h-[190px] rounded-2xl overflow-hidden bg-white shadow-sm premium-shadow cursor-pointer transition-transform duration-300 hover:scale-[1.02]"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                {/* Visual Label */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 flex flex-col justify-end">
                  <span className="text-white text-xs font-semibold uppercase tracking-wider opacity-90 mb-1">
                    Производство
                  </span>
                  <p className="text-white text-sm font-semibold leading-snug tracking-tight">
                    {item.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column - scrolling DOWN */}
        <div className="h-full overflow-hidden relative">
          <div className="flex flex-col gap-4 animate-marquee-down py-2">
            {SECOND_COLUMN.map((item, index) => (
              <div
                key={`${item.id}-${index}`}
                className="group relative h-[190px] rounded-2xl overflow-hidden bg-white shadow-sm premium-shadow cursor-pointer transition-transform duration-300 hover:scale-[1.02]"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-108"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                {/* Visual Label */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 flex flex-col justify-end">
                  <span className="text-white text-xs font-semibold uppercase tracking-wider opacity-90 mb-1">
                    Фирменный стиль
                  </span>
                  <p className="text-white text-sm font-semibold leading-snug tracking-tight">
                    {item.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
